## Module <salon_management>

#### 20.12.2019
#### Version 13.0.1.0.0
##### ADD
- Initial Commit salon_management
